#include "DecodeMessage.h"
#include <iostream>

// Default constructor
DecodeMessage::DecodeMessage()
{
    // Nothing specific to initialize here
}

// Destructor
DecodeMessage::~DecodeMessage()
{
    // Nothing specific to clean up
}

// Function to decode the hidden message.
std::string DecodeMessage::decodeFromImage(const ImageMatrix &image, const std::vector<std::pair<int, int>> &edgePixels)
{
    std::string binaryString;

    // Extracting LSB's from Edge Pixels.
    for (const auto &pixel : edgePixels)
    {
        double pixelValue = image.get_data(pixel.first, pixel.second);
        int intPixelValue = static_cast<int>(pixelValue);
        int lsb = intPixelValue & 1; // Extractinng LSB.
        binaryString += std::to_string(lsb);
    }
    while (binaryString.length() % 7 != 0)
    {
        binaryString = "0" + binaryString; // Padding with leading 0's.
    }
    // Binary to ASCII.
    std::string decodedMessage;
    for (int i = 0; i < binaryString.length(); i += 7)
    {
        std::string segment = binaryString.substr(i, 7);
        int decimalValue = std::stoi(segment, nullptr, 2);
        if (decimalValue <= 32)
        {
            decimalValue += 33;
        }
        if (decimalValue == 127)
        {
            decimalValue = 126;
        }
        decodedMessage += static_cast<char>(decimalValue);
    }
    return decodedMessage;
}