// ImageSharpening.cpp
#include <iostream>

#include "ImageSharpening.h"
#include <cmath>

ImageSharpening::ImageSharpening()
{
    // Constructor implementation
    kernelHeight = 3;
    kernelWidth = 3;

    // Allocate memory for the kernel.
    blurringKernel = new double *[kernelHeight];
    for (int i = 0; i < kernelHeight; i++)
    {
        blurringKernel[i] = new double[kernelWidth];
    }

    for (int i = 0; i < kernelHeight; i++)
    {
        for (int j = 0; j < kernelWidth; j++)
        {
            blurringKernel[i][j] = 1.0 / 9.0;
        }
    }
}

ImageSharpening::~ImageSharpening()
{
    // Destructor implementation.
    if (blurringKernel != nullptr)
    {
        for (int i = 0; i < kernelHeight; i++)
        {
            delete[] blurringKernel[i];
        }
        delete[] blurringKernel;
        blurringKernel = nullptr;
    }
}

ImageMatrix ImageSharpening::sharpen(const ImageMatrix &inputImage, double k)
{
    int imgHeight = inputImage.get_height();
    int imgWidth = inputImage.get_width();

    ImageMatrix noisyImage(imgHeight, imgWidth);

    for (int i = 0; i < imgHeight; i++)
    {
        for (int j = 0; j < imgWidth; j++)
        {
            double sum = 0.0;
            for (int m = 0; m < kernelHeight; m++)
            {
                for (int n = 0; n < kernelWidth; n++)
                {
                    int row = i - kernelHeight / 2 + m;
                    int col = j - kernelWidth / 2 + n;
                    if (row >= 0 && row < inputImage.get_height() && col >= 0 && col < inputImage.get_width())
                    {
                        sum += inputImage.get_data(row, col) * blurringKernel[m][n];
                    }
                }
            }
            // Store the result in the output matrix.
            if (i < noisyImage.get_height() && j < noisyImage.get_width())
            {
                noisyImage.set_data(i, j, sum);
            }
        }
    }

    ImageMatrix sharpImage(imgHeight, imgWidth);

    // ImageSharpening.
    for (int i = 0; i < imgHeight; ++i)
    {
        for (int j = 0; j < imgWidth; ++j)
        {
            double newValue = inputImage.get_data(i, j) + k * (inputImage.get_data(i, j) - noisyImage.get_data(i, j));
            if (std::abs(newValue) < 0.5)
            {
                newValue = 0.0;
                std::cout << "New value is less than 0.5" << std::endl;
            }

            // Clip values to [0, 255]
            newValue = std::max(0.0, std::min(255.0, newValue));

            sharpImage.set_data(i, j, newValue);
        }
    }

    return sharpImage;
}