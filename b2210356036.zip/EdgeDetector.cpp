#include "EdgeDetector.h"
#include <cmath> // Added for the sqrt function

EdgeDetector::EdgeDetector()
{
    // Define Sobel operators.
    Gx = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
    Gy = {{-1, -2, -1}, {0, 0, 0}, {1, 2, 1}};
}

// Destructor
EdgeDetector::~EdgeDetector() {}

std::vector<std::pair<int, int>> EdgeDetector::detectEdges(const ImageMatrix &inputImage)
{
    // Convolve the input image with the Sobel operators.
    ImageMatrix Ix = convolution(inputImage, Gx);
    ImageMatrix Iy = convolution(inputImage, Gy);

    ImageMatrix gradientMagnitude = calculateGradientMagnitude(Ix, Iy);

    // Thresholding
    double thresholdValue = calculateThreshold(gradientMagnitude);
    std::vector<std::pair<int, int>> edgePixels;

    int rows = gradientMagnitude.get_height();
    int cols = gradientMagnitude.get_width();

    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            if (gradientMagnitude.get_data(i, j) > thresholdValue)
            {
                edgePixels.emplace_back(i, j);
            }
        }
    }

    return edgePixels;
}

ImageMatrix EdgeDetector::calculateGradientMagnitude(const ImageMatrix &Ix, const ImageMatrix &Iy)
{
    int rows = Ix.get_height();
    int cols = Ix.get_width();
    ImageMatrix gradientMagnitude(rows, cols);

    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            double magnitude = std::sqrt(Ix.get_data(i, j) * Ix.get_data(i, j) + Iy.get_data(i, j) * Iy.get_data(i, j));
            gradientMagnitude.set_data(i, j, magnitude);
        }
    }

    return gradientMagnitude;
}

double EdgeDetector::calculateThreshold(const ImageMatrix &gradientMagnitude)
{
    int rows = gradientMagnitude.get_height();
    int cols = gradientMagnitude.get_width();

    // Calculate the sum of gradient magnitudes.
    double sum = 0.0;
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            sum += gradientMagnitude.get_data(i, j);
        }
    }

    // Calculatiing the threshold value.
    double threshold = sum / (rows * cols);
    return threshold;
}

ImageMatrix EdgeDetector::convolution(const ImageMatrix &inputImage, const std::vector<std::vector<double>> &kernel)
{
    int inputHeight = inputImage.get_height();
    int inputWidth = inputImage.get_width();
    int kernelHeight = kernel.size();
    int kernelWidth = kernel[0].size();
    int padding = true;
    int stride = 1;

    int outputHeight = (inputHeight - kernelHeight + 2 * padding) / stride + 1;
    int outputWidth = (inputWidth - kernelWidth + 2 * padding) / stride + 1;

    ImageMatrix outputImage(outputHeight, outputWidth);

    for (int y = 0; y < outputHeight; y++)
    {
        for (int x = 0; x < outputWidth; x++)
        {
            double result = 0.0;
            for (int i = 0; i < kernelHeight; i++)
            {
                for (int j = 0; j < kernelWidth; j++)
                {
                    // Calculating the input image pixel coordinates based on the stride and padding.
                    int inputX = x * stride - padding + j;
                    int inputY = y * stride - padding + i;

                    // Check if the kernel is within the bounds of the input image.
                    if (inputX >= 0 && inputX < inputWidth && inputY >= 0 && inputY < inputHeight)
                    {
                        result += inputImage.get_data(inputY, inputX) * kernel[i][j];
                    }
                }
            }
            outputImage.set_data(y, x, result);
        }
    }

    return outputImage;
}
