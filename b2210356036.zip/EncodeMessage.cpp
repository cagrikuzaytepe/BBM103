#include "EncodeMessage.h"
#include <string>
#include <bitset>
#include <vector>
#include <cmath>

EncodeMessage::EncodeMessage(){};
EncodeMessage::~EncodeMessage(){};

ImageMatrix EncodeMessage::encodeMessageToImage(const ImageMatrix &img, const std::string &message, const std::vector<std::pair<int, int>> &positions)
{

    ImageMatrix encodedImage = img;

    // Convert the message to a binary string and apply character transformation
    std::string binaryMessage;
    for (size_t i = 0; i < message.length() - 1; i++)
    {
        int asciiValue = static_cast<int>(message[i + 1]);

        // Apply character transformation if the index is prime.
        if (isPrime(i + 1))
        {
            asciiValue += Fibonacci(i + 1);
        }

        if (asciiValue < 33)
        {
            asciiValue += 33;
            if (asciiValue >= 127)
            {
                asciiValue = 126;
            }
        }
        else if (asciiValue >= 127)
        {
            asciiValue = 126;
        }

        // Convert the ASCII value to a 7-bit binary string.
        std::string binaryChar = std::bitset<7>(asciiValue).to_string();
        binaryMessage += binaryChar;
    }

    // Right Circular Shifting.
    int shiftAmount = binaryMessage.length() / 2;
    std::string shiftedMessage = binaryMessage.substr(binaryMessage.length() - shiftAmount) + binaryMessage.substr(0, binaryMessage.length() - shiftAmount);

    // Embedding.
    size_t bitIndex = 0;
    for (const auto &position : positions)
    {
        int x = position.first;
        int y = position.second;
        double pixelValue = encodedImage.get_data(x, y);
        int lsb = static_cast<int>(pixelValue) & 1;

        if (bitIndex < shiftedMessage.length())
        {
            double newLsb = (lsb & 0xFF) | (shiftedMessage[bitIndex] - '0'); // Clear the LSB and set it to the new bit
            pixelValue = (pixelValue - lsb) + newLsb;
            encodedImage.set_data(x, y, pixelValue);
            bitIndex++;
        }
        else
        {
            break;
        }
    }
    return encodedImage;
}

int EncodeMessage::Fibonacci(int n)
{
    if (n <= 0)
    {
        return 0;
    }
    if (n == 1)
    {
        return 1;
    }

    int prev = 0;
    int current = 1;

    for (int i = 2; i <= n; i++)
    {
        int next = prev + current;
        prev = current;
        current = next;
    }

    return current;
}
// Check if a number is prime.
bool EncodeMessage::isPrime(int n)
{
    if (n <= 1)
    {
        return false;
    }
    if (n <= 3)
    {
        return true;
    }
    if (n % 2 == 0 || n % 3 == 0)
    {
        return false;
    }
    for (int i = 5; i * i <= n; i += 6)
    {
        if (n % i == 0 || n % (i + 2) == 0)
        {
            return false;
        }
    }
    return true;
}
