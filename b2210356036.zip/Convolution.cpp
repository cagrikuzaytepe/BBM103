#include "Convolution.h"
#include "ImageMatrix.h"

// Constructors
Convolution::Convolution()
{
    kernel = nullptr;
    kernelHeight = 0;
    kernelWidth = 0;
    stride = 1;
    padding = true;
}

Convolution::Convolution(double **customKernel, int kernelHeight, int kernelWidth, int stride, bool padding)
{
    this->kernelHeight = kernelHeight;
    this->kernelWidth = kernelWidth;
    this->stride = stride;
    this->padding = padding;

    // Defining kernel and values in kernel.
    kernel = new double *[kernelHeight];
    for (int i = 0; i < kernelHeight; i++)
    {
        kernel[i] = new double[kernelWidth];
        for (int j = 0; j < kernelWidth; j++)
        {
            kernel[i][j] = customKernel[i][j];
        }
    }
}

Convolution::Convolution(const Convolution &other)
{
    kernelHeight = other.kernelHeight;
    kernelWidth = other.kernelWidth;
    stride = other.stride;
    padding = other.padding;

    // Defining kernel and values in kernel.
    kernel = new double *[kernelHeight];
    for (int i = 0; i < kernelHeight; i++)
    {
        kernel[i] = new double[kernelWidth];
        for (int j = 0; j < kernelWidth; j++)
        {
            kernel[i][j] = other.kernel[i][j];
        }
    }
}

Convolution &Convolution::operator=(const Convolution &other)
{
    if (this == &other)
    {
        return *this;
    }
    // Copies the values of the other object to this object.
    kernelHeight = other.kernelHeight;
    kernelWidth = other.kernelWidth;
    stride = other.stride;
    padding = other.padding;

    // Deallocate the kernel memory
    kernel = new double *[kernelHeight];
    for (int i = 0; i < kernelHeight; i++)
    {
        kernel[i] = new double[kernelWidth];
        for (int j = 0; j < kernelWidth; j++)
        {
            kernel[i][j] = other.kernel[i][j];
        }
    }

    return *this;
}

Convolution::~Convolution()
{
    // Making kernel nullptr.

    if (kernel != nullptr)
    {
        for (int i = 0; i < kernelHeight; i++)
        {
            delete[] kernel[i];
        }
        delete[] kernel;
    }
}

ImageMatrix Convolution::convolve(const ImageMatrix &input_image) const
{
    int inputHeight = input_image.get_height();
    int inputWidth = input_image.get_width();

    int outputHeight = (inputHeight - kernelHeight) / stride + 1;
    int outputWidth = (inputWidth - kernelWidth) / stride + 1;

    // Create the output ImageMatrix.
    ImageMatrix outputImage(outputHeight, outputWidth);

    // Implementing the convolve operation.
    for (int y = 0; y < outputHeight; y++)
    {
        for (int x = 0; x < outputWidth; x++)
        {
            // Calculating the result of the convolution operation.
            double result = 0.0;
            for (int i = 0; i < kernelHeight; i++)
            {
                for (int j = 0; j < kernelWidth; j++)
                {
                    // Calculate the input coordinates.
                    int inputX = x * stride - padding + j;
                    int inputY = y * stride - padding + i;

                    // Checking if the input coordinates are valid.
                    if (inputX >= 0 && inputX < inputWidth && inputY >= 0 && inputY < inputHeight)
                    {
                        // Add the result of the convolution operation.
                        result += input_image.get_data(inputY, inputX) * kernel[i][j];
                    }
                }
            }

            // Setting the output image data.
            outputImage.set_data(y, x, result);
        }
    }

    return outputImage;
}
