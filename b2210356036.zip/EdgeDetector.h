#ifndef EDGE_DETECTOR_H
#define EDGE_DETECTOR_H

#include "ImageMatrix.h"
#include <vector>
#include "ImageSharpening.h"

class EdgeDetector
{
public:
    EdgeDetector();
    ~EdgeDetector();

    std::vector<std::pair<int, int>> detectEdges(const ImageMatrix &input_image);
    ImageMatrix calculateGradientMagnitude(const ImageMatrix &Ix, const ImageMatrix &Iy);
    double calculateThreshold(const ImageMatrix &gradientMagnitude);
    ImageMatrix convolution(const ImageMatrix &inputImage, const std::vector<std::vector<double>> &kernel);

private:
    std::vector<std::vector<double>> Gx;
    std::vector<std::vector<double>> Gy;
};

#endif // EDGE_DETECTOR_H
