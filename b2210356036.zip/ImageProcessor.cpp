#include "ImageProcessor.h"

#include <string>
#include "DecodeMessage.h"
#include "EncodeMessage.h"
#include "ImageSharpening.h"
#include "EdgeDetector.h"
#include "ImageMatrix.h"
#include <bitset>
#include <cmath>
#include <algorithm>
// Default constructor
ImageProcessor::ImageProcessor()
{
}

// Destructor
ImageProcessor::~ImageProcessor() {}

// Decode hidden message from the image
std::string ImageProcessor::decodeHiddenMessage(const ImageMatrix &img)
{
    // ImageSharpening.
    ImageSharpening sharpening;
    ImageMatrix sharpenedImg = sharpening.sharpen(img, 2.0); // You can adjust the sharpening factor as needed

    // Edge Detecting
    EdgeDetector edgeDetector;
    std::vector<std::pair<int, int>> edgePixels = edgeDetector.detectEdges(sharpenedImg);

    // Decoding.
    DecodeMessage decoder;
    std::string decodedMessage = decoder.decodeFromImage(sharpenedImg, edgePixels);

    return decodedMessage;
}

// Encoding the message into the image.
ImageMatrix ImageProcessor::encodeHiddenMessage(const ImageMatrix &img, const std::string &message)
{

    EdgeDetector edgeDetector;

    // Edge Detecting.
    std::vector<std::pair<int, int>> positions = edgeDetector.detectEdges(img);

    EncodeMessage encoder;
    ImageMatrix encodedImage = encoder.encodeMessageToImage(img, message, positions);

    return encodedImage;
}