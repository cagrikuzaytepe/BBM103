import sys

get_input = sys.argv
new_values = get_input[1].split(",")
my_list = []

for i in new_values:
    c = int(i)
    my_list.append(c)

for k in my_list:
    if k < 0:
        my_list.remove(k)

for i in my_list:
    total = i
    last_number = int(len(my_list)/2+1)
    if i == 1:
        for j in range(1,last_number):
            my_list.pop(j)
    else:
        break

for x in my_list:
    if x == 1:
        continue

    total = x
    while total-1 < len(my_list):
        my_list.pop(total-1)
        total = total+x-1


str1 = str(my_list).replace("[", "")
str1 = str1.replace("]", "")
str1 = str1.replace(",", "")

print(str1)