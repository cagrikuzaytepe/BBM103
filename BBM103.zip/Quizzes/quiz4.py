import sys

my_input = sys.argv[1]
my_output = sys.argv[2]

get_input = open(my_input, "r", encoding="UTF-8")
get_output = open(my_output, "w", encoding="UTF-8")

my_list = []

for i in get_input:
    line = i.replace("\n", "").split("	")

    message_id = line[0]
    message_num = line[1]
    message = line[2]

    my_list.append([message_id, message_num, message])

    my_list.sort()

total = 1
for x in my_list:
    if "0" in x:
        print("Message", str(total), file=get_output)
        total += 1
    for y in x:
        print(y, end="  ", file=get_output)
    print(file=get_output)

get_input.close()