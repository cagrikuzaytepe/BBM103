import sys

try:
    my_input_file = sys.argv[1]
    my_input = open(my_input_file, "r", encoding="UTF-8")

    try:
        my_comp_file = sys.argv[2]
        my_comp = open(my_comp_file, "r", encoding="UTF-8")
    except IOError:
            print("IOError: cannot open " + str(my_comp_file))

    else:
        my_list = []
        a = 0

        try:

            for x in my_input:
                    try:
                        line = x.replace("\n", "").split(" ")
                        div = float(line[0])
                        non_div = float(line[1])
                        my_from = float(line[2])
                        to = float(line[3])

                        for y in range(int(my_from), int(to)+1):
                            if y % div == 0 and y % non_div != 0:
                                my_list.append(str(y))
                                var = str().join(i+" " for i in my_list)

                        print("------------")
                        print("My results: " + var)
                        a_list = []

                        for i in my_comp.readlines():
                            f = (i.replace("\n", "").split(" "))
                            my_var1 = str().join(d + " " for d in f)
                            a_list.append(my_var1)
                            my_var = a_list


                        print("Results to compare: "+str(my_var[a]))


                        assert var == my_var[a]
                        print("Goool!!!")
                        my_list.clear()
                        a += 1

                    except IndexError:
                        print("------------")
                        print("IndexError: number of operands less than expected. ")
                        print("Given input: " + str(x))
                        a += 1


                    except ZeroDivisionError:
                        print("------------")
                        print("ZeroDivisionError: You can’t divide by 0. ")
                        print("Given input " + str(x))
                        a += 1


                    except ValueError:
                        print("------------")
                        print("ValueError: only numeric input is accepted. ")
                        print("Given input " + str(x))
                        a += 1


                    except AssertionError:
                        my_list.clear()
                        print("Assertion Error: results don’t match. ")
                        a += 1



        except NameError:
                    print("------------")
                    print("kaBOOM: run for your life!")

except IOError:
    print("IOError: cannot open " + str(my_input_file))
    print("- Game Over -")

except IndexError:
    print("IndexError: number of input files less than expected.")
    print("- Game Over -")
else:
    print("- Game Over -")