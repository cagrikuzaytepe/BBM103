import sys
try:
    t = sys.argv  # I will add 3 numbers. (1: 2 points) (2: 3 points) (3: single throws)
    p = sys.argv
    s = sys.argv
    result = int(t[1])*2 + int(p[1])*3 + int(s[1])*1  # Calculation
    print(result)
except IndexError:
    pass

def  healthStatus(height, mass ):
    BMI = mass / (height ** 2)

    if BMI < 18.5:
        return "underweight"
    if 18.5 <= BMI < 24.9:
        return "healthy"
    if 24.9 <= BMI < 30:
        return "overweight"
    else:
        return "obese"