import sys

a = sys.argv

result = str(int(a[1]) ** int(a[2]))

my_list = [int(i) for i in result]

try:
    for i in my_list:
        if len(my_list) == 2:
            total = my_list[0] + my_list[1]

        elif len(my_list) == 3:
            total = my_list[0] + my_list[1] + my_list[2]

        elif len(my_list) == 4:
            total = my_list[0] + my_list[1] + my_list[2] + my_list[3]

        elif len(my_list) == 5:
            total = my_list[0] + my_list[1] + my_list[2] + my_list[3] + my_list[4]

        elif len(my_list) == 6:
            total = my_list[0] + my_list[1] + my_list[2] + my_list[3] + my_list[4] + my_list[5]

        elif len(my_list) == 7:
            total = my_list[0] + my_list[1] + my_list[2] + my_list[3] + my_list[4] + my_list[5] + my_list[6]

        elif len(my_list) == 8:
            total = my_list[0] + my_list[1] + my_list[2] + my_list[3] + my_list[4] + my_list[5] + my_list[6] +my_list[7]

        else:
            total = my_list[0] + my_list[1] + my_list[2] + my_list[3] + my_list[4] + my_list[5] + my_list[6] + my_list[7] + my_list[8]
    print(total)

except IndexError:
    print("This is only one digit.")

