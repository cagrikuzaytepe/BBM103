import sys

number = int(sys.argv[1])

diamond = [" " * m + "*" * ((number - m) * 2 - 1) for m in list(range(number - 1, 0, -1)) + list(range(0, number))]
for m in range(0, len(diamond)):
    print(*diamond[m], sep="")
