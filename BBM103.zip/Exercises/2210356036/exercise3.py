b= int(input("number: "))
c=int(input("number: "))

d=b**2-4*c
if d<0:
    print("there is no roots.")

r1=(b-(d**0.5))/2
r2=(b+(d**0.5))/2

print("roots are {},{} .".format(r1,r2))