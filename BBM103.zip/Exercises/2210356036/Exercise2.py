my_list = [1000, 298, 3579, 100, 200, -45, 900]
my_list.sort()
print(my_list)

def find_largest(list, n):
    print(my_list[n])

find_largest(my_list,6)