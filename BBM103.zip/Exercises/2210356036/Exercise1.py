def star_dict(n):
    dict={}
    for d in range(1,n+1) :
        list = []
        for x in range(d):
            list.append("*")
        dict[d]=list
    return dict

n = int(input("Enter a number: "))

print(star_dict(n))