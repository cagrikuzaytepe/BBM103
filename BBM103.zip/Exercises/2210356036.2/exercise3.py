import random
a=random.randint(1,25)
n=int(input("Enter a number between 1-25: "))
while True:
    if n<a:
        n=int(input("Please increase your number: "))
    if n>a:
        n = int(input("Please decrease your number: "))
    else:
        print("You won!")
        break