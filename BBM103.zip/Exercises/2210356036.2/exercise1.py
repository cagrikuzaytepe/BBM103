N=int(input("Enter a number: "))
list=[]
list2=[]
for i in range(N+1):
    if i%2!=0:
        list2.append(i)

    if i%2==0:
        list.append(i)

print("sum of odds: ", sum(list2))
print("average of evens: ",sum(list)/len(list))