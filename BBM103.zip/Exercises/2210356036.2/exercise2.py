e=input("Enter your e-mail adress: ")

if "@" and "." in e:
    print("This is a valid e-mail adress. ")
else:
    print("This is not a valid e-mail adress.")