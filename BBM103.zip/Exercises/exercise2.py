get_input = open("input.txt","r", encoding="UTF-8")
get_output = open("output.txt", "w", encoding="UTF-8")
read_output= open("output.txt", "r", encoding="UTF-8")


my_dict = {}
alphabet = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]

def createCategory(line):
        for i in line:
            command = line.split(" ")[0]
            if command == "CREATECATEGORY":
                category = line.split(" ")[1]
                numbers = str(line.replace("\n", " ").split(" ")[2]).split("x")
                new_dict = {}
                if category in my_dict:
                    return "1"
                i = 0
                for col in range(int(numbers[1])):
                    i += 1
                    for row in range(int(numbers[0])):
                        str1 = alphabet[i-1]+str(row)
                        new_dict[str1] = "X"
                        my_dict[category] = new_dict
                return "2"

def sellTicket(line):
            for i in line:
                    line.replace("\n","")
                    a = line.split(" ")
                    name = a[1]
                    type1 = a[2]
                    cat = a[3]
                    number = a[4:-1]

            if type1 == "student":
                        for i in number:
                                if len(i) < 3:
                                    if my_dict[cat][i] == "X":
                                        my_dict[cat][i] = "S"
                                        print("Success: " + str(name) + " has bought " + str(i) + " at " + str(cat),file=get_output)
                                    else:
                                        print("Warning: The seat " + str(i) + " cannot be sold to " + str(name) + " since it was already sold!",file=get_output)

                                else:
                                    harf = i[0]

                                    my_str2 = "".join(x + " " for x in i if x.isdigit())
                                    a = my_str2.split(" ")

                                    first = int(a[0])

                                    if len(a) == 3:
                                        second = int(a[1])
                                    else:
                                        second = int(str(a[1]) + str(a[2]))

                                    c = 0
                                    for i in range(first, second+1):

                                            astr = str(harf+str(i))

                                            alist= []
                                            anotherlist = []

                                            if second > int(len(my_dict[cat].keys())**0.5):
                                                print("Error: The category " + str(cat) +" has less column than the specified index " + str(astr)[0]+str(astr)[1]+"-"+str(second)+ "!",file=get_output)
                                                break
                                            else:
                                                alist.append(my_dict[cat][astr])

                                                for k in alist:
                                                    if k == "X":
                                                        anotherlist.append(i)
                                                if len(alist) != len(anotherlist):
                                                    print("Error:  The seats " + str(harf) + str(first) + "-" + str(
                                                        second) + " cannot be sold to " + str(
                                                        name) + " due some of them have already been sold!",
                                                          file=get_output)
                                                    break

                                                else:
                                                    my_dict[cat][astr] = "S"
                                                    c += 1
                                                    if c == len(alist):
                                                        print("Success: " + str(name) + " has bought " + str(
                                                        harf) + str(
                                                        first) + "-" + str(
                                                        second) + " at " + str(
                                                        cat), file=get_output)





            if type1 == "full":
                for i in number:
                    if len(i) < 3:
                        if my_dict[cat][i] == "X":
                            my_dict[cat][i] = "F"
                            print("Success: " + str(name) + " has bought " + str(i) + " at " + str(cat),file=get_output)
                        else:
                            print("Warning: The seat " + str(i) + " cannot be sold to " + str(name) + " since it was already sold!",file=get_output)
                    else:
                        harf = i[0]

                        my_str2 = "".join(x + " " for x in i if x.isdigit())
                        a = my_str2.split(" ")

                        first = int(a[0])

                        if len(a) == 3:
                            second = int(a[1])


                        else:
                            second = int(str(a[1]) + str(a[2]))
                        c = 0
                        for i in range(first, second + 1):
                            astr = str(harf + str(i))

                            alist = []
                            anotherlist = []

                            if second > int(len(my_dict[cat].keys()) ** 0.5):
                                print("Error: The category " + str(cat) + " has less column than the specified index " +
                                      str(astr)[0] + str(astr)[1] + "-" + str(second) + "!", file=get_output)
                                break
                            else:
                                alist.append(my_dict[cat][astr])

                                for i in alist:
                                    if i == "X":
                                        anotherlist.append(i)

                                if len(alist) != len(anotherlist):
                                    print("Error:  The seats " + str(harf) + str(first) + "-" + str(
                                        second) + " cannot be sold to " + str(
                                        name) + " due some of them have already been sold!",
                                          file=get_output)
                                    break


                                else:
                                    my_dict[cat][astr] = "F"
                                    c += 1
                                    if c == len(alist):
                                        print("Success: " + str(name) + " has bought " + str(harf) + str(
                                            first) + "-" + str(
                                            second) + " at " + str(
                                            cat), file=get_output)








            if type1 == "season":
                for i in number:
                    if len(i) < 3:
                        if my_dict[cat][i] == "X":
                            my_dict[cat][i] = "F"
                            print("Success: " + str(name) + " has bought " + str(i) + " at " + str(cat),
                                  file=get_output)
                        else:
                            print("Warning: The seat " + str(i) + " cannot be sold to " + str(
                                name) + " since it was already sold!", file=get_output)
                    else:
                        harf = i[0]

                        my_str2 = "".join(x + " " for x in i if x.isdigit())
                        a = my_str2.split(" ")

                        first = int(a[0])

                        if len(a) == 3:
                            second = int(a[1])


                        else:
                            second = int(str(a[1]) + str(a[2]))
                        c = 0
                        for i in range(first, second + 1):
                            astr = str(harf + str(i))

                            alist = []
                            anotherlist = []

                            if second > int(len(my_dict[cat].keys()) ** 0.5):
                                print("Error: The category " + str(cat) + " has less column than the specified index " +
                                      str(astr)[0] + str(astr)[1] + "-" + str(second) + "!", file=get_output)
                                break
                            else:
                                alist.append(my_dict[cat][astr])

                                for i in alist:
                                    if i == "X":
                                        anotherlist.append(i)

                                if len(alist) != len(anotherlist):
                                    print("Error:  The seats " + str(harf) + str(first) + "-" + str(
                                        second) + " cannot be sold to " + str(
                                        name) + " due some of them have already been sold!",
                                          file=get_output)
                                    break


                                else:
                                    my_dict[cat][astr] = "F"
                                    c += 1
                                    if c == len(alist):
                                        print("Success: " + str(name) + " has bought " + str(harf) + str(
                                            first) + "-" + str(
                                            second) + " at " + str(
                                            cat), file=get_output)


def cancelTicket(line):
    for i in line:
        command = line.split(" ")[0]
        if command == "CANCELTICKET":
            a = line.split(" ")
            cat = a[1]
            seats = a[2]

            try:
                if my_dict[cat][seats] == "S" or "F" or "T":
                    my_dict[cat][seats] = "X"
                    return "Success: The seat "+ str(seats)+ " at "+str(cat)+ " has been canceled and now ready to sell again\n"
                else:
                    return "Error: The seat "+ str(seats)+ " at "+str(cat)+ " has already been free! Nothing to cancel\n"
            except KeyError:
                return "Error: The category "+str(cat)+ " has less column than the specified index " +str(seats)+ "!\n"
def balance(line):
    for i in line:
        command = line.split(" ")[0]
        if command == "BALANCE":
            a = line.split(" ")
            cat = a[1]
            total = 0
            other = 0
            seas  = 0

            for i in my_dict[cat]:
                if my_dict[cat][i] == "S":
                    total += 1
                if my_dict[cat][i] == "F":
                    other += 1
                if my_dict[cat][i] == "T":
                    seas += 1

                result = (10*total) + (20*other) + (250*seas)

            return "\nCategory report of "+ str(cat)+"\n"+"--------------------------------\n"+ "Sum of students = "+str(total)+ " , Sum of full pay = "+str(other)+ " , Sum of season ticket = "+str(seas)+ " and Revenues = "+ str(result)+"\n"

def showCategory(line):
            a = line.split(" ")
            cat = a[1]
            row = len(my_dict[cat].keys())**0.5
            col = len(my_dict[cat].keys())**0.5

            for y in range(int(col)):
                print(alphabet[int(col)-1-y],end=" 	", file=get_output)
                for x in range(int(row)):
                        print(my_dict[cat][alphabet[int(col)-1-y] + str(x)], end=" 	", file=get_output)
                print("\n",file=get_output)



            for x in range(int(row)):
                print("\t"+str(x), end=" ", file=get_output)



for i in get_input.readlines():
    line = i.replace("\n", " ")
    command = i.split(" ")[0]

    if command == "CREATECATEGORY" :
        cat = line.split(" ")[1]
        numbers = str(line.replace("\n", " ").split(" ")[2]).split("x")
        result = int(numbers[0])*int(numbers[1])
        created = createCategory(line)
        if created == "2":
            output_str = "The category " + cat + " having " + str(result) + " seats has been created.\n"
            get_output.write(output_str)
        else:
            output_str = "Can not create the category for the second time. The stadium has already " + cat + "\n"
            get_output.write(output_str)

    elif command == "SELLTICKET" :
        name = line.split(" ")[1]
        seats = line.split(" ")[4:-1]
        cat = line.split(" ")[3]
        sellTicket(line)

    elif command == "CANCELTICKET" :
        variable = cancelTicket(line)
        get_output.write(variable)

    elif command == "BALANCE" :
        variable = balance(line)
        get_output.write(variable)

    elif command == "SHOWCATEGORY" :
        showCategory(line)