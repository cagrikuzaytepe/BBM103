import sys

my_val1 = sys.argv[1]
my_val = my_val1.split(",")
get_input = open("Students.txt", "r", encoding="UTF-8")

my_list = []

for i in get_input:
    name = i.split(":")[0]
    university_name = i.split(":")[1]
    my_list.append(name)
for y in my_val:
    if y in my_list:
        print("Name: {}, University: {}".format(y,university_name))

    else:
        print("No record of "+ y +" was found!")
