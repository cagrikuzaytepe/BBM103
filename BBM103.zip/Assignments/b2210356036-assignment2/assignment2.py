person_list=[]
                                                                                            # Kadir Çağrı Kuzaytepe 2210356036
def create(person_str, person_list):
    name = person_str.split(" ")[1].replace(",", "")
    for i in person_list:
        if i[0] == name:
            return False
    person_str = person_str[7:]   #Removing 'create' part from string.
    list = person_str.split(", ")
    person_list.append(list)
    return True

def list(person_list):
    list_str = """Patient	Diagnosis	Disease			Disease		Treatment		Treatment
Name	Accuracy	Name			Incidence	Name			Risk
-------------------------------------------------------------------------\n"""
    for i in person_list:                   # I calculate the maximum character of the line and added spaces for making it full.
        str_name = i[0]
        difference = 8-len(str_name)
        how_many_tab = 0
        while difference > 0:
           how_many_tab += 1
           difference -= 4
        for dx in range(how_many_tab):
            str_name += "\t"
        str_disease_name = i[2]
        difference = 16 - len(str_disease_name)
        how_many_tab = 0
        while difference > 0:
            how_many_tab += 1
            difference -= 4
        for dx in range(how_many_tab):
            str_disease_name += "\t"
        str_treatment_name = i[4]
        difference = 16 - len(str_treatment_name)
        how_many_tab = 0
        while difference > 0:
            how_many_tab += 1
            difference -= 4
        for dx in range(how_many_tab):
            str_treatment_name += "\t"
        list_str += str_name+str(format(float(i[1])*100, ".2f"))+"%"+"\t\t"+str_disease_name+i[3]+"\t"+str_treatment_name+str(int(float(i[5])*100))+"%"+"\n"
    return list_str

def remove(person_list, name):
    for i in person_list:
        if i[0] == name:
            person_list.remove(i)
            return True
    return False

def probability(person_list, name, for_recommendation=False):
    for i in person_list:
        if name == i[0]:
            prob = round(int(i[3].split("/")[0])/(((int(i[3].split("/")[1])-int(i[3].split("/")[0]))*(1-float(i[1]))+int(i[3].split("/")[0])*(float(i[1]))))*100,2)
            if for_recommendation:
                return prob
            cancer_name = i[2].lower()
            return "Patient "+name+" has a probability of "+str(prob)+"% of having "+cancer_name+".\n"
    return "Probability for "+name+" cannot be calculated due to absence.\n"

def recommendation(person_list, name):
    for i in person_list:
        if name == i[0]:
            prob = probability(person_list,name,True)
            if prob > float(i[5])*100:
                return "1"      # It means that, he or she should take the treatment.
            else:
                return "2"      # It means that, he or she should NOT take the treatment.
    return "0"                  # Can not found.

def get_input():
    input = open("doctors_aid_inputs.txt", "r", encoding="UTF-8")
    return input

def get_output(a):
    output = open("doctors_aid_outputs.txt", "w", encoding="UTF-8")
    output.write(a)

for i in get_input():
    line = i.replace("\n", "")
    what_to_do = line.split(" ")[0]

    if what_to_do == "create":
        name = line.split(" ")[1]
        created = create(line, person_list)
        if created:
            output_str = "Patient " + name.strip(",") + " is recorded.\n"
        else:
            output_str = "Patient " + name.strip(",") + " cannot be recorded due to duplication.\n"
        get_output(output_str)

    elif what_to_do == "remove":
        name = line.split(" ")[1]
        removed = remove(person_list, name)
        if removed:
            output_str = "Patient " + name + " is removed.\n"
        else:
            output_str = "Patient " + name + " cannot be removed due to absence.\n"
        get_output(output_str)

    elif what_to_do == "list":
        get_output(list(person_list))

    elif what_to_do == "probability":
        get_output(probability(person_list, line.split(" ")[1]))

    elif what_to_do == "recommendation":
        name = line.split(" ")[1]
        recom = recommendation(person_list, name)

        if recom == "0":
            output_str = "Recommendation for " + name + " cannot be calculated due to absence.\n"
        elif recom == "1":
            output_str = "System suggests " + name + " to have the treatment.\n"
        else:
            output_str = "System suggests " + name + " NOT to have the treatment.\n"
        get_output(output_str)