import sys

player1 = sys.argv[1]
player2 = sys.argv[2]
p1move = sys.argv[3]
p2move = sys.argv[4]

p1_input = open(player1, "r", encoding="UTF-8")
p2_input = open(player2, "r", encoding="UTF-8")
p1_moves = open(p1move, "r", encoding="UTF-8")
p2_moves = open(p2move, "r", encoding="UTF-8")
battleship_outputs = open("Battleship.out","w",encoding="UTF-8")

alphabet = ["A","B","C","D","E","F","G","H","I","J"]

p1_grid = [["-" for i in range(10)] for j in range(10)]

p2_grid = [["-" for i in range(10)] for j in range(10)]

p1_hidden_grid = [["-" for i in range(10)] for j in range(10)]

p2_hidden_grid = [["-" for i in range(10)] for j in range(10)]

a = 0
for i in p1_input:
    a += 1
    if "P;P" in i:
        line = i.rfind("P",0,len(i))-1    #I used "a" for the columns and I used "line" for the rows.
        letters = i.replace(";", "")
        letters.replace("PP","")
        if len(i) > 13:
            my_index = line-len(letters)+3
            p1_grid[a-1][my_index-1] = "P"
            p1_grid[a-1][my_index] = "P"

        else:
            p1_grid[a-1][line-1] = "P"
            p1_grid[a-1][line] = "P"
    elif "P" in i:
        line = i.rfind("P", 0, len(i))
        p1_grid[a-2][line] = "P"
        p1_grid[a-1][line] = "P"

    elif "B;B;B;B" in i:
        line = i.rfind("B;B;B;B", 0 , len(i))
        p1_grid[a-1][line] = "B"
        p1_grid[a-1][line+1] = "B"
        p1_grid[a-1][line+2] = "B"
        p1_grid[a-1][line+3] = "B"

    elif ";;B;;" in i:
        if a-4>0:
            line = i.rfind("B", 0, len(i))
            p1_grid[a-4][line] = "B"
            p1_grid[a-3][line] = "B"
            p1_grid[a-2][line] = "B"
            p1_grid[a-1][line] = "B"
        else:
            pass

    elif "S;S;S" in i:
        line = i.rfind("S;S;S",0,len(i))
        p1_grid[a-1][line] = "S"
        p1_grid[a-1][line+1] = "S"
        p1_grid[a-1][line+2] = "S"

    elif "S" in i:
        line = i.rfind("S",0 , len(i))
        p1_grid[a-1][line] = "S"
        p1_grid[a][line] = "S"
        p1_grid[a+1][line] = "S"

    elif "D" in i:
        line = i.rfind("D",0, len(i))
        p1_grid[a-1][line] = "D"
        p1_grid[a][line] = "D"
        p1_grid[a+1][line] = "D"

    elif "C" in i:
        line = i.rfind("C",0, len(i))
        p1_grid[a-1][line] = "C"
        p1_grid[a][line] = "C"
        p1_grid[a+1][line] = "C"
        p1_grid[a+2][line] = "C"
        p1_grid[a+3][line] = "C"

a = 0
for i in p2_input:
    a += 1
    if "P;P" in i:
        line = i.rfind("P;P",0,len(i))
        p2_grid[a-1][line-1] = "P"
        p2_grid[a-1][line] = "P"

    elif "P" in i:
        line = i.rfind("P",0,len(i))
        p2_grid[a-1][line-1] = "P"
        p2_grid[a][line-1] = "P"

    elif "B;B;B;B" in i:
        line = i.rfind("B;B;B;B",0,len(i))
        p2_grid[a-1][line] = "B"
        p2_grid[a-1][line+1] = "B"
        p2_grid[a-1][line+2] = "B"
        p2_grid[a-1][line+3] = "B"

    elif "B" in i:
        line = i.rfind("B",0,len(i))
        p2_grid[a-4][line] = "B"
        p2_grid[a-3][line] = "B"
        p2_grid[a-2][line] = "B"
        p2_grid[a-1][line] = "B"

    elif "D" in i:
        line = i.rfind("D",0,len(i))
        if p2_grid[a][line] == "D":
            pass
        else:
            p2_grid[a-1][line] = "D"
            p2_grid[a][line] = "D"
            p2_grid[a+1][line] = "D"

    elif "S" in i:
        line = i.rfind("S",0,len(i))
        p2_grid[a-1][line] = "S"
        p2_grid[a][line] = "S"
        p2_grid[a+1][line] = "S"

    if "C;C;C;C;C" in i:
        line = i.rfind("C;C;C;C;C",0,len(i))
        p2_grid[a-1][line] = "C"
        p2_grid[a-1][line+1] = "C"
        p2_grid[a-1][line+2] = "C"
        p2_grid[a-1][line+3] = "C"
        p2_grid[a-1][line+4] = "C"
#I create a function for the situation of the ships in the game.
def ships():
    total = 0
    atotal = 0
    for i in p1_grid:
        total = total + i.count("C")
        cc = total
    for j in p2_grid:
        atotal = atotal + j.count("C")
    if cc == 0:
        print("Carrier X\t\t\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Carrier X", file=battleship_outputs)
        else:
            print("Carrier -", file=battleship_outputs)
    else:
        print("Carrier -\t\t\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Carrier X", file=battleship_outputs)
        else:
            print("Carrier -", file=battleship_outputs)

    total = 0
    atotal = 0
    for i in p1_grid:
        total = total + i.count("B")
        bb = total
    for j in p2_grid:
        atotal = atotal + j.count("B")

    if bb == 0:
        print("Battleship XX\t\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Battleship XX", file=battleship_outputs)
        elif 0 < atotal <= 4:
            print("Battleship X-", file=battleship_outputs)
        else:
            print("Battleship --", file=battleship_outputs)
    elif 0 < bb <= 4:
        print("Battleship X-\t\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Battleship XX", file=battleship_outputs)
        elif 0 < atotal <= 4:
            print("Battleship X-", file=battleship_outputs)
        else:
            print("Battleship --", file=battleship_outputs)
    else:
        print("Battleship --\t\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Battleship XX", file=battleship_outputs)
        elif 0 < atotal <= 4:
            print("Battleship X-", file=battleship_outputs)
        else:
            print("Battleship --", file=battleship_outputs)
    total = 0
    atotal = 0
    for i in p1_grid:
        total = total + i.count("D")
        dd = total
    for j in p2_grid:
        atotal = atotal + j.count("D")

    if dd == 0:
        print("Destroyer X\t\t\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Destroyer X", file=battleship_outputs)
        else:
            print("Destroyer -", file=battleship_outputs)
    else:
        print("Destroyer -\t\t\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Destroyer X", file=battleship_outputs)
        else:
            print("Destroyer -", file=battleship_outputs)
    total = 0
    atotal = 0
    for i in p1_grid:
        total = total + i.count("S")
        ss = total
    for j in p2_grid:
        atotal = atotal + j.count("S")

    if ss == 0:
        print("Submarine X\t\t\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Submarine X", file=battleship_outputs)
        else:
            print("Submarine -", file=battleship_outputs)
    else:
        print("Submarine -\t\t\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Submarine X", file=battleship_outputs)
        else:
            print("Submarine -", file=battleship_outputs)

    total = 0
    atotal = 0
    for i in p1_grid:
        total = total + i.count("P")
        pp = total
    for j in p2_grid:
        atotal = atotal + j.count("P")
    if pp == 0:
        print("Petrol Boat XXXX\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Petrol Boat XXXX", file=battleship_outputs)
        elif 0 < atotal <= 2:
            print("Petrol Boat XXX-", file=battleship_outputs)
        elif 2 < atotal <= 4:
            print("Petrol Boat XX--", file=battleship_outputs)
        elif 4 < atotal <= 6:
            print("Petrol Boat X---", file=battleship_outputs)
        else:
            print("Petrol Boat ----", file=battleship_outputs)
    elif 0 < pp <= 2:
        print("Petrol Boat XXX-\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Petrol Boat XXXX", file=battleship_outputs)
        elif 0 < atotal <= 2:
            print("Petrol Boat XXX-", file=battleship_outputs)
        elif 2 < atotal <= 4:
            print("Petrol Boat XX--", file=battleship_outputs)
        elif 4 < atotal <= 6:
            print("Petrol Boat X---", file=battleship_outputs)
        else:
            print("Petrol Boat ----", file=battleship_outputs)
    elif 2 < pp <= 4:
        print("Petrol Boat XX--\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Petrol Boat XXXX", file=battleship_outputs)
        elif 0 < atotal <= 2:
            print("Petrol Boat XXX-", file=battleship_outputs)
        elif 2 < atotal <= 4:
            print("Petrol Boat XX--", file=battleship_outputs)
        elif 4 < atotal <= 6:
            print("Petrol Boat X---", file=battleship_outputs)
        else:
            print("Petrol Boat ----", file=battleship_outputs)
    elif 4 < pp <= 6:
        print("Petrol Boat X---\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Petrol Boat XXXX", file=battleship_outputs)
        elif 0 < atotal <= 2:
            print("Petrol Boat XXX-", file=battleship_outputs)
        elif 2 < atotal <= 4:
            print("Petrol Boat XX--", file=battleship_outputs)
        elif 4 < atotal <= 6:
            print("Petrol Boat X---", file=battleship_outputs)
        else:
            print("Petrol Boat ----", file=battleship_outputs)
    else:
        print("Petrol Boat ----\t\t\t", end="", file=battleship_outputs)
        if atotal == 0:
            print("Petrol Boat XXXX", file=battleship_outputs)
        elif 0 < atotal <= 2:
            print("Petrol Boat XXX-", file=battleship_outputs)
        elif 2 < atotal <= 4:
            print("Petrol Boat XX--", file=battleship_outputs)
        elif 4 < atotal <= 6:
            print("Petrol Boat X---", file=battleship_outputs)
        else:
            print("Petrol Boat ----", file=battleship_outputs)
    print(file=battleship_outputs)

for i in p1_moves:
    moves1 = i.split(";")
    moves1.remove("")

for j in p2_moves:
    moves2 = j.split(";")
    moves2.remove("")

def play(rounds, player):     # "player" decides who is going to play.
    if player % 2 == 0:      # Player 2 plays.
        try:
            player = 2
            global moves2
            move = moves2[0]
            r, b = moves2[0].split(",")
            r = int(r) - 1
            moves2 = moves2[1:]
            c = alphabet.index(b)
            assert r <= 10 and c <=10

            if p1_grid[r][c] != "-":
                    p1_hidden_grid[r][c] = "X"
                    p1_grid[r][c] = "X"
            else:
                    p1_hidden_grid[r][c] = "O"
                    p1_grid[r][c] = "O"

            print("Enter your move: "+str(r+1)+","+str(b)+"\n",file=battleship_outputs)
            print("Player 2's move\n", file=battleship_outputs)
            print("Round : "+str(rounds-1),"\t\t\t\t\t","Grid Size:  10x10\n",file=battleship_outputs)
            print("Player1’s Hidden Board\t\tPlayer 2's Hidden Board",file=battleship_outputs)
            for a in range(10):
                if a == 0:
                    print(" ", alphabet[a], end=" ", file=battleship_outputs)
                else:
                    print(alphabet[a], end=" ", file=battleship_outputs)
            print(end="      ",file=battleship_outputs)

            for a in range(10):
                if a == 0:
                    print(" ", alphabet[a], end=" ", file=battleship_outputs)
                else:
                    print(alphabet[a], end=" ", file=battleship_outputs)
            print(file=battleship_outputs)

            for k in range(10):
                if k == 9:
                    print(k+1,end="",file=battleship_outputs)
                else:
                    print(k+1,end=" ",file=battleship_outputs)
                for l in range(10):
                    print(p1_hidden_grid[k][l], end=" ", file=battleship_outputs)
                print("     ", end=" ", file=battleship_outputs)
                if k == 9:
                    print(k + 1, end="", file=battleship_outputs)
                else:
                    print(k + 1, end=" ", file=battleship_outputs)
                for p in range(10):
                    print(p2_hidden_grid[k][p], end=" ", file=battleship_outputs)
                print(file=battleship_outputs)
            print(file=battleship_outputs)
            ships()

            CC=0
            BB=0
            DD=0
            SS=0
            PP=0
            for i in p1_grid:
                CC = CC + i.count("C")
                BB = BB + i.count("B")
                DD = DD + i.count("D")
                SS = SS + i.count("S")
                PP = PP + i.count("P")
            C2 = 0
            B2 = 0
            D2 = 0
            S2 = 0
            P2 = 0
            for j in p2_grid:
                C2 = C2 + j.count("C")
                B2 = B2 + j.count("B")
                D2 = D2 + j.count("D")
                S2 = S2 + j.count("S")
                P2 = P2 + j.count("P")

            if CC == 0 and BB == 0 and DD == 0 and SS == 0 and PP == 0:  #Draw or not.
                if C2 == 0 and B2 == 0 and D2 == 0 and S2 == 0 and P2 == 0:
                    print("It is a draw!\n", file=battleship_outputs)
                    print("Final Information", file=battleship_outputs)
                    print("Player1’s Board\t\t\t\tPlayer 2's Board", file=battleship_outputs)
                    for a in range(10):
                        if a == 0:
                            print(" ", alphabet[a], end=" ", file=battleship_outputs)
                        else:
                            print(alphabet[a], end=" ", file=battleship_outputs)
                    print(end="      ", file=battleship_outputs)

                    for a in range(10):
                        if a == 0:
                            print(" ", alphabet[a], end=" ", file=battleship_outputs)
                        else:
                            print(alphabet[a], end=" ", file=battleship_outputs)
                    print(file=battleship_outputs)

                    for k in range(10):
                        if k == 9:
                            print(k + 1, end="", file=battleship_outputs)
                        else:
                            print(k + 1, end=" ", file=battleship_outputs)
                        for l in range(10):
                            print(p1_grid[k][l], end=" ", file=battleship_outputs)
                        print("     ", end=" ", file=battleship_outputs)
                        if k == 9:
                            print(k + 1, end="", file=battleship_outputs)
                        else:
                            print(k + 1, end=" ", file=battleship_outputs)
                        for p in range(10):
                            print(p2_grid[k][p], end=" ", file=battleship_outputs)
                        print(file=battleship_outputs)
                    print(file=battleship_outputs)
                    ships()
                else:
                    print("Player 2 Wins!\n", file=battleship_outputs)
                    print("Final Information", file=battleship_outputs)
                    print("Player1’s Board\t\t\t\tPlayer 2's Board", file=battleship_outputs)
                    for a in range(10):
                        if a == 0:
                            print(" ", alphabet[a], end=" ", file=battleship_outputs)
                        else:
                            print(alphabet[a], end=" ", file=battleship_outputs)
                    print(end="      ", file=battleship_outputs)

                    for a in range(10):
                        if a == 0:
                            print(" ", alphabet[a], end=" ", file=battleship_outputs)
                        else:
                            print(alphabet[a], end=" ", file=battleship_outputs)
                    print(file=battleship_outputs)

                    for k in range(10):
                        if k == 9:
                            print(k + 1, end="", file=battleship_outputs)
                        else:
                            print(k + 1, end=" ", file=battleship_outputs)
                        for l in range(10):
                            print(p1_grid[k][l], end=" ", file=battleship_outputs)
                        print("     ", end=" ", file=battleship_outputs)
                        if k == 9:
                            print(k + 1, end="", file=battleship_outputs)
                        else:
                            print(k + 1, end=" ", file=battleship_outputs)
                        for p in range(10):
                            print(p2_grid[k][p], end=" ", file=battleship_outputs)
                        print(file=battleship_outputs)
                    print(file=battleship_outputs)
                    ships()
            else:
                    rounds += 1
                    play(rounds, player+1)

            if rounds == 1: # If round equals to 1, it will print this statement.
                print("Battle of Ships Game", file=battleship_outputs)
                print("Player 1's move\n", file=battleship_outputs)
                print("Round : " + str(rounds), "\t\t\t\t\t","Grid Size:  10x10\n", file=battleship_outputs)
                print("Player1’s Hidden Board\t\tPlayer 2's Hidden Board", file=battleship_outputs)
                for a in range(10):
                    if a == 0:
                        print(" ", alphabet[a], end=" ", file=battleship_outputs)
                    else:
                        print(alphabet[a], end=" ", file=battleship_outputs)
                    print(end="      ", file=battleship_outputs)

                for a in range(10):
                    if a == 0:
                        print(" ", alphabet[a], end=" ", file=battleship_outputs)
                    else:
                        print(alphabet[a], end=" ", file=battleship_outputs)
                    print(file=battleship_outputs)

                for k in range(10):
                    if k == 9:
                        print(k + 1, end="", file=battleship_outputs)
                    else:
                        print(k + 1, end=" ", file=battleship_outputs)
                    for l in range(10):
                        print(p1_hidden_grid[k][l], end=" ", file=battleship_outputs)
                    print("     ", end=" ", file=battleship_outputs)
                    if k == 9:
                        print(k + 1, end="", file=battleship_outputs)
                    else:
                        print(k + 1, end=" ", file=battleship_outputs)
                    for p in range(10):
                        print(p2_hidden_grid[k][p], end=" ", file=battleship_outputs)
                    print(file=battleship_outputs)
                print(file=battleship_outputs)
                ships()
                rounds += 1
                play(rounds, player+2)
        except IndexError:
            if len(moves2) == 0:
                print("Index Error: Please try again!\n", file=battleship_outputs)
            else:
                print("Index Error: Please try again!\n", file=battleship_outputs)
                moves2 = moves2[2:]
                play(rounds, player)
        except ValueError:
            first_val = move.split(",")[0]
            sec_val = move.split(",")[1]
            if len(move) > 5:
                print("Value Error: There is a missing part. Please try again!\n", file=battleship_outputs)
                moves2 = moves2[2:]
                play(rounds, player)
            elif len(move) > 3:
                print("Value Error: There is extra comma. Please try again!\n", file=battleship_outputs)
                moves2 = moves2[2:]
                play(rounds, player)
            elif first_val == sec_val:
                print("Value Error: Wrong type. Please try again!\n", file=battleship_outputs)
                moves2 = moves2[2:]
                play(rounds, player)
        except AssertionError:
            print("Assertion Error: Please try again!\n", file=battleship_outputs)
            moves2 = moves2[2:]
            play(rounds, player)
    else:
            try:
                player = 1
                global moves1
                move = moves1[0]
                r, b = moves1[0].split(",")
                r = int(r) - 1
                moves1 = moves1[1:]
                c = alphabet.index(b)
                assert r <=10 and c <= 10

                if p2_grid[r][c] != "-":
                    p2_hidden_grid[r][c] = "X"
                    p2_grid[r][c] = "X"
                else:
                    p2_hidden_grid[r][c] = "O"
                    p2_grid[r][c] = "O"

                print("Enter your move: " + str(r+1) + "," + str(b),"\n", file=battleship_outputs)
                print("Player 1's move\n", file=battleship_outputs)
                print("Round : " + str(rounds-1), "\t\t\t\t\t", "Grid Size:  10x10\n", file=battleship_outputs)
                print("Player1’s Hidden Board\t\tPlayer 2's Hidden Board",file=battleship_outputs)
                for a in range(10):
                    if a == 0:
                        print(" ",alphabet[a],end=" ",file=battleship_outputs)
                    else:
                        print(alphabet[a],end=" ",file=battleship_outputs)
                print(end="      ",file=battleship_outputs)

                for a in range(10):
                    if a == 0:
                        print(" ", alphabet[a], end=" ", file=battleship_outputs)
                    else:
                        print(alphabet[a], end=" ", file=battleship_outputs)
                print(file=battleship_outputs)

                for k in range(10):
                    if k == 9:
                        print(k + 1, end="", file=battleship_outputs)
                    else:
                        print(k + 1, end=" ", file=battleship_outputs)
                    for l in range(10):
                        print(p1_hidden_grid[k][l],end=" ",file=battleship_outputs)
                    print("     ",end=" ",file=battleship_outputs)
                    if k == 9:
                        print(k + 1, end="", file=battleship_outputs)
                    else:
                        print(k + 1, end=" ", file=battleship_outputs)
                    for p in range(10):
                        print(p2_hidden_grid[k][p], end=" ", file=battleship_outputs)
                    print(file=battleship_outputs)
                print(file=battleship_outputs)
                ships()
                CC = 0   # I count them for the final information of the game.
                BB = 0
                DD = 0
                SS = 0
                PP = 0
                for i in p2_grid:
                        CC = CC + i.count("C")
                        BB = BB + i.count("B")
                        DD = DD + i.count("D")
                        SS = SS + i.count("S")
                        PP = PP + i.count("P")
                C2 = 0
                B2 = 0
                D2 = 0
                S2 = 0
                P2 = 0
                for j in p1_grid:
                    C2 = C2 + j.count("C")
                    B2 = B2 + j.count("B")
                    D2 = D2 + j.count("D")
                    S2 = S2 + j.count("S")
                    P2 = P2 + j.count("P")

                if CC == 0 and BB == 0 and DD == 0 and SS == 0 and PP == 0:
                    if C2 == 0 and B2 == 0 and D2 == 0 and S2 == 0 and P2 == 0:
                        print("It is a draw!\n", file=battleship_outputs)
                        print("Final Information", file=battleship_outputs)
                        print("Player1’s Board\t\t\t\tPlayer 2's Board", file=battleship_outputs)
                        for a in range(10):
                            if a == 0:
                                print(" ", alphabet[a], end=" ", file=battleship_outputs)
                            else:
                                print(alphabet[a], end=" ", file=battleship_outputs)
                        print(end="      ", file=battleship_outputs)

                        for a in range(10):
                            if a == 0:
                                print(" ", alphabet[a], end=" ", file=battleship_outputs)
                            else:
                                print(alphabet[a], end=" ", file=battleship_outputs)
                        print(file=battleship_outputs)

                        for k in range(10):
                            if k == 9:
                                print(k + 1, end="", file=battleship_outputs)
                            else:
                                print(k + 1, end=" ", file=battleship_outputs)
                            for l in range(10):
                                print(p1_grid[k][l], end=" ", file=battleship_outputs)
                            print("     ", end=" ", file=battleship_outputs)
                            if k == 9:
                                print(k + 1, end="", file=battleship_outputs)
                            else:
                                print(k + 1, end=" ", file=battleship_outputs)
                            for p in range(10):
                                print(p2_grid[k][p], end=" ", file=battleship_outputs)
                            print(file=battleship_outputs)
                        print(file=battleship_outputs)
                        ships()
                    else:
                        print("Player 1 Wins!\n", file=battleship_outputs)
                        print("Final Information", file=battleship_outputs)
                        print("Player1’s Board\t\t\t\tPlayer 2's Board", file=battleship_outputs)
                        for a in range(10):
                            if a == 0:
                                print(" ", alphabet[a], end=" ", file=battleship_outputs)
                            else:
                                print(alphabet[a], end=" ", file=battleship_outputs)
                        print(end="      ", file=battleship_outputs)

                        for a in range(10):
                            if a == 0:
                                print(" ", alphabet[a], end=" ", file=battleship_outputs)
                            else:
                                print(alphabet[a], end=" ", file=battleship_outputs)
                        print(file=battleship_outputs)

                        for k in range(10):
                            if k == 9:
                                print(k + 1, end="", file=battleship_outputs)
                            else:
                                print(k + 1, end=" ", file=battleship_outputs)
                            for l in range(10):
                                print(p1_grid[k][l], end=" ", file=battleship_outputs)
                            print("     ", end=" ", file=battleship_outputs)
                            if k == 9:
                                print(k + 1, end="", file=battleship_outputs)
                            else:
                                print(k + 1, end=" ", file=battleship_outputs)
                            for p in range(10):
                                print(p2_grid[k][p], end=" ", file=battleship_outputs)
                            print(file=battleship_outputs)
                        print(file=battleship_outputs)
                        ships()
                else:
                    play(rounds, player + 1)
            except IndexError:
                    if len(moves1)>0:
                        print("Index Error: Please try again!\n", file=battleship_outputs)
                        moves1 = moves1[2:]
                        play(rounds, player)
                    else:
                        print("Index Error: Please try again!\n", file=battleship_outputs)
            except ValueError:
                first_val = move.split(",")[0]
                sec_val = move.split(",")[1]
                if len(move) > 5:
                    print("Value Error: There is a missing part. Please try again!\n", file=battleship_outputs)
                    moves2 = moves1[2:]
                    play(rounds, player)
                elif len(move) > 3:
                    print("Value Error: There is extra comma. Please try again!\n", file=battleship_outputs)
                    moves2 = moves1[2:]
                    play(rounds, player)
                elif first_val == sec_val:
                    print("Value Error: Wrong type. Please try again!\n", file=battleship_outputs)
                    moves2 = moves1[2:]
                    play(rounds, player)
            except AssertionError:
                print("Assertion Error: Please try again!\n",file=battleship_outputs)
                moves1 = moves1[2:]
                play(rounds, player)
play(1,1)